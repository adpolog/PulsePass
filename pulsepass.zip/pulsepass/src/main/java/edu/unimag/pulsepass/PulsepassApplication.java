package edu.unimag.pulsepass;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PulsepassApplication {

	public static void main(String[] args) {
		SpringApplication.run(PulsepassApplication.class, args);
	}

}
